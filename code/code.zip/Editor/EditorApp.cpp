
#include "EditorApp.h"
#include "Panels.h"
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h" // we still init DX11 backend to let ImGui own a device if user plugs one later
#include <d3d11.h>
#include <wrl.h>
#include <vector>
#include <string>

using Microsoft::WRL::ComPtr;

struct Entity { int id; std::string name; };
struct Scene  { std::vector<Entity> entities; int selected=-1; };
struct EditorCamera { float aspect=16.f/9.f; };

static EditorApp* g_app = nullptr;
static Scene g_scene;
static EditorCamera g_cam;

static ComPtr<ID3D11Device>           g_dev;
static ComPtr<ID3D11DeviceContext>    g_ctx;

LRESULT CALLBACK EditorApp::WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (ImGui_ImplWin32_WndProcHandler(h,m,w,l)) return true;
    switch(m) {
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProc(h,m,w,l);
}

bool EditorApp::Init(HINSTANCE hi) {
    // Win32 window
    WNDCLASSEXW wc{ sizeof(WNDCLASSEXW) };
    wc.style = CS_CLASSDC; wc.lpfnWndProc = WndProc; wc.hInstance = hi;
    wc.lpszClassName = L"MiniEditorWnd";
    RegisterClassExW(&wc);
    hWnd = CreateWindowExW(0, wc.lpszClassName, L"Editor (Docking UI)",
        WS_OVERLAPPEDWINDOW, 100,100, 1600,900, nullptr,nullptr,hi,nullptr);

    // Create a bare DX11 device so ImGui DX11 backend can work (no swapchain/rtv here)
    UINT flags=0;
    D3D_FEATURE_LEVEL fl;
    D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, nullptr, 0,
        D3D11_SDK_VERSION, g_dev.GetAddressOf(), &fl, g_ctx.GetAddressOf());

    // Init ImGui
    if (!InitImGui()) return false;

    // Initial scene data
    g_scene.entities.push_back({0,"Camera"});
    g_scene.entities.push_back({1,"Cube"});
    g_scene.selected = 1;

    ShowWindow(hWnd, SW_SHOWDEFAULT);
    UpdateWindow(hWnd);
    g_app = this;
    return true;
}

bool EditorApp::InitImGui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.ConfigFlags &= ~ImGuiConfigFlags_ViewportsEnable; // stay inside main window
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(hWnd);
    ImGui_ImplDX11_Init(g_dev.Get(), g_ctx.Get());
    return true;
}

void EditorApp::ShutdownImGui() {
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
}

void EditorApp::Tick() {
    MSG msg{};
    while (PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
        TranslateMessage(&msg); DispatchMessage(&msg);
        if (msg.message==WM_QUIT) { PostQuitMessage(0); return; }
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    bool open = true;
    Panels::DrawDockspace(&open);
    Panels::DrawHierarchy(g_scene);
    Panels::DrawInspector(g_scene);
    Panels::DrawViewport(g_scene, g_cam);

    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

int EditorApp::Run() {
    while (true) Tick();
    return 0;
}

int WINAPI wWinMain(HINSTANCE hi, HINSTANCE, PWSTR, int) {
    EditorApp app;
    if (!app.Init(hi)) return -1;
    return app.Run();
}
