
#pragma once
#include <windows.h>

struct Scene;
struct EditorCamera;

class EditorApp {
public:
    bool Init(HINSTANCE);
    int  Run();

private:
    static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
    bool InitImGui();
    void ShutdownImGui();
    void Tick();

private:
    HWND hWnd{};
};
